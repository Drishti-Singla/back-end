const { v4: uuidv4 } = require('uuid');
const { readDB, writeDB } = require('../config/db');

class Patient {
  constructor(data) {
    this.id = data.id || uuidv4();
    this.name = data.name;
    this.age = data.age;
    this.gender = data.gender;
    this.contactNumber = data.contactNumber;
    this.address = data.address;
    this.bloodGroup = data.bloodGroup;
    this.medicalHistory = data.medicalHistory || [];
    this.createdAt = data.createdAt || new Date().toISOString();
    this.updatedAt = new Date().toISOString();
  }

  static async getAll() {
    return await readDB('patients.json');
  }

  static async getById(id) {
    const patients = await this.getAll();
    return patients.find(patient => patient.id === id);
  }

  static async create(patientData) {
    const patients = await this.getAll();
    const newPatient = new Patient(patientData);
    patients.push(newPatient);
    await writeDB('patients.json', patients);
    return newPatient;
  }

  static async update(id, patientData) {
    const patients = await this.getAll();
    const index = patients.findIndex(patient => patient.id === id);
    
    if (index === -1) return null;
    
    const updatedPatient = new Patient({
      ...patients[index],
      ...patientData,
      id,
      updatedAt: new Date().toISOString()
    });
    
    patients[index] = updatedPatient;
    await writeDB('patients.json', patients);
    return updatedPatient;
  }

  static async delete(id) {
    const patients = await this.getAll();
    const filteredPatients = patients.filter(patient => patient.id !== id);
    
    if (filteredPatients.length === patients.length) return false;
    
    await writeDB('patients.json', filteredPatients);
    return true;
  }

  static async search(query) {
    const patients = await this.getAll();
    return patients.filter(patient => 
      patient.name.toLowerCase().includes(query.toLowerCase()) ||
      patient.contactNumber.includes(query)
    );
  }
}

module.exports = Patient;