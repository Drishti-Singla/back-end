// middleware/errorHandler.js
const errorHandler = (err, req, res, next) => {
    let error = { ...err };
    error.message = err.message;
  
    // Log error for development
    console.error(err);
  
    // Custom error handling could be added here
    // For example, handling specific types of errors
  
    res.status(error.statusCode || 500).json({
      success: false,
      error: error.message || 'Server Error'
    });
  };
  
  module.exports = errorHandler;
  
  // middleware/logger.js
  const logger = (req, res, next) => {
    console.log(
      `${req.method} ${req.protocol}://${req.get('host')}${req.originalUrl}`
    );
    next();
  };
  
  module.exports = logger;