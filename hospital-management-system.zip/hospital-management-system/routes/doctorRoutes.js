// routes/doctorRoutes.js
const express = require('express');
const router = express.Router();
const { 
  getAllDoctors, 
  getDoctorById, 
  createDoctor, 
  updateDoctor, 
  deleteDoctor, 
  getDoctorsByDepartment, 
  searchDoctors 
} = require('../controllers/doctorController');
const { protect, authorize } = require('../middleware/auth');

// Public routes
router.get('/search/:query', searchDoctors);
router.get('/department/:departmentId', getDoctorsByDepartment);

// Protected routes
router.use(protect);

router.route('/')
  .get(getAllDoctors)
  .post(authorize('admin'), createDoctor);

router.route('/:id')
  .get(getDoctorById)
  .put(authorize('admin'), updateDoctor)
  .delete(authorize('admin'), deleteDoctor);

module.exports = router;

