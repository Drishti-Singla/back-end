// models/Department.js
const { v4: uuidv4 } = require('uuid');
const { readDB, writeDB } = require('../config/db');

class Department {
  constructor(data) {
    this.id = data.id || uuidv4();
    this.name = data.name;
    this.description = data.description || '';
    this.location = data.location || '';
    this.headOfDepartment = data.headOfDepartment || '';
    this.createdAt = data.createdAt || new Date().toISOString();
    this.updatedAt = new Date().toISOString();
  }

  static async getAll() {
    return await readDB('departments.json');
  }

  static async getById(id) {
    const departments = await this.getAll();
    return departments.find(department => department.id === id);
  }

  static async create(departmentData) {
    const departments = await this.getAll();
    const newDepartment = new Department(departmentData);
    departments.push(newDepartment);
    await writeDB('departments.json', departments);
    return newDepartment;
  }

  static async update(id, departmentData) {
    const departments = await this.getAll();
    const index = departments.findIndex(department => department.id === id);
    
    if (index === -1) return null;
    
    const updatedDepartment = new Department({
      ...departments[index],
      ...departmentData,
      id,
      updatedAt: new Date().toISOString()
    });
    
    departments[index] = updatedDepartment;
    await writeDB('departments.json', departments);
    return updatedDepartment;
  }

  static async delete(id) {
    const departments = await this.getAll();
    const filteredDepartments = departments.filter(department => department.id !== id);
    
    if (filteredDepartments.length === departments.length) return false;
    
    await writeDB('departments.json', filteredDepartments);
    return true;
  }
}

module.exports = Department;