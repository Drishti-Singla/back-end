# Hospital Management System API

A comprehensive hospital management system built with Node.js and using the file system for data storage.

## Features

* Patient management
* Doctor management
* Appointment scheduling
* Department organization
* Medication inventory
* User authentication and authorization
* Role-based access control

## Project Structure

```
hospital-management-system/
├── config/
│   └── db.js                  # Database configuration
├── data/
│   ├── patients.json          # Patient data storage
│   ├── doctors.json           # Doctor data storage
│   ├── appointments.json      # Appointment data storage
│   ├── departments.json       # Department data storage
│   ├── medications.json       # Medication data storage
│   └── users.json             # User data storage
├── models/
│   ├── Patient.js             # Patient model
│   ├── Doctor.js              # Doctor model
│   ├── Appointment.js         # Appointment model
│   ├── Department.js          # Department model
│   ├── Medication.js          # Medication model
│   └── User.js                # User model
├── controllers/
│   ├── patientController.js   # Patient controller
│   ├── doctorController.js    # Doctor controller
│   ├── appointmentController.js # Appointment controller
│   ├── departmentController.js # Department controller
│   ├── medicationController.js # Medication controller
│   └── authController.js      # Authentication controller
├── routes/
│   ├── patientRoutes.js       # Patient routes
│   ├── doctorRoutes.js        # Doctor routes
│   ├── appointmentRoutes.js   # Appointment routes
│   ├── departmentRoutes.js    # Department routes
│   ├── medicationRoutes.js    # Medication routes
│   └── authRoutes.js          # Authentication routes
├── middleware/
│   ├── auth.js                # Authentication middleware
│   ├── errorHandler.js        # Error handling middleware
│   └── logger.js              # Logging middleware
├── utils/
│   ├── helpers.js             # Helper functions
│   └── validators.js          # Validation functions
├── server.js                  # Server entry point
├── package.json               # Project dependencies
└── README.md                  # Project documentation
```

## Installation

1. Clone the repository
   ```
   git clone https://github.com/yourusername/hospital-management-system.git
   cd hospital-management-system
   ```

2. Install dependencies
   ```
   npm install
   ```

3. Create a `.env` file in the root directory with the following variables:
   ```
   PORT=5000
   NODE_ENV=development
   JWT_SECRET=your_jwt_secret_key
   ```

## Running the Application

Start the server:
```
npm start
```

For development with auto-restart:
```
npm run dev
```

## API Endpoints

### Authentication
* `POST /api/auth/register` - Register a new user
* `POST /api/auth/login` - User login
* `GET /api/auth/me` - Get current user
* `PUT /api/auth/profile` - Update user profile
* `PUT /api/auth/password` - Change user password

### Patients
* `GET /api/patients` - Get all patients
* `GET /api/patients/:id` - Get patient by ID
* `POST /api/patients` - Create a new patient
* `PUT /api/patients/:id` - Update patient information
* `DELETE /api/patients/:id` - Delete a patient

### Doctors
* `GET /api/doctors` - Get all doctors
* `GET /api/doctors/:id` - Get doctor by ID
* `POST /api/doctors` - Add a new doctor
* `PUT /api/doctors/:id` - Update doctor information
* `DELETE /api/doctors/:id` - Delete a doctor

### Appointments
* `GET /api/appointments` - Get all appointments
* `GET /api/appointments/:id` - Get appointment by ID
* `POST /api/appointments` - Schedule a new appointment
* `PUT /api/appointments/:id` - Update appointment details
* `DELETE /api/appointments/:id` - Cancel an appointment
* `GET /api/appointments/patient/:patientId` - Get appointments by patient
* `GET /api/appointments/doctor/:doctorId` - Get appointments by doctor

### Departments
* `GET /api/departments` - Get all departments
* `GET /api/departments/:id` - Get department by ID
* `POST /api/departments` - Create a new department
* `PUT /api/departments/:id` - Update department information
* `DELETE /api/departments/:id` - Delete a department
* `GET /api/departments/:id/doctors` - Get doctors in a department

### Medications
* `GET /api/medications` - Get all medications
* `GET /api/medications/:id` - Get medication by ID
* `POST /api/medications` - Add a new medication
* `PUT /api/medications/:id` - Update medication information
* `DELETE /api/medications/:id` - Delete a medication
* `PUT /api/medications/:id/stock` - Update medication stock

## Request & Response Examples

### Authentication

#### Register a new user
```
POST /api/auth/register
```

Request:
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "password": "password123",
  "role": "doctor"
}
```

Response:
```json
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "user": {
    "id": "user123",
    "name": "John Doe",
    "email": "john@example.com",
    "role": "doctor"
  }
}
```

### Patient Management

#### Create a new patient
```
POST /api/patients
```

Request:
```json
{
  "name": "Jane Smith",
  "age": 35,
  "gender": "female",
  "contact": "555-1234",
  "address": "123 Main St",
  "bloodGroup": "O+",
  "medicalHistory": "No significant medical history"
}
```

Response:
```json
{
  "success": true,
  "data": {
    "id": "patient123",
    "name": "Jane Smith",
    "age": 35,
    "gender": "female",
    "contact": "555-1234",
    "address": "123 Main St",
    "bloodGroup": "O+",
    "medicalHistory": "No significant medical history",
    "createdAt": "2025-03-06T12:00:00.000Z"
  }
}
```

## Error Handling

The API uses standard HTTP status codes to indicate the success or failure of requests:

* 200 - OK: Request succeeded
* 201 - Created: Resource created successfully
* 400 - Bad Request: Invalid request parameters
* 401 - Unauthorized: Authentication failed
* 403 - Forbidden: User not authorized for this action
* 404 - Not Found: Resource not found
* 500 - Internal Server Error: Server-side error

Error responses follow this format:
```json
{
  "success": false,
  "error": "Error message"
}
```

## Authentication & Authorization

The API uses JWT (JSON Web Tokens) for authentication. Include the token in the Authorization header:

```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

Access control is role-based with these roles:
* Admin: Full access to all resources
* Doctor: Access to patients, appointments, and medications
* Nurse: Limited access to patients and appointments
* Patient: Access to own data and appointments

## Data Models

### User
```
{
  id: String,
  name: String,
  email: String,
  password: String (hashed),
  role: String (admin|doctor|nurse|patient),
  createdAt: Date
}
```

### Patient
```
{
  id: String,
  name: String,
  age: Number,
  gender: String,
  contact: String,
  address: String,
  bloodGroup: String,
  medicalHistory: String,
  createdAt: Date
}
```

### Doctor
```
{
  id: String,
  userId: String,
  name: String,
  specialization: String,
  contact: String,
  departmentId: String,
  schedule: Array,
  createdAt: Date
}
```

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.