// controllers/medicationController.js
const Medication = require('../models/Medication');

// Get all medications
exports.getAllMedications = async (req, res) => {
  try {
    const medications = await Medication.getAll();
    res.status(200).json({
      success: true,
      count: medications.length,
      data: medications
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error'
    });
  }
};

// Get medication by ID
exports.getMedicationById = async (req, res) => {
  try {
    const medication = await Medication.getById(req.params.id);
    
    if (!medication) {
      return res.status(404).json({
        success: false,
        error: 'Medication not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: medication
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error'
    });
  }
};

// Create new medication
exports.createMedication = async (req, res) => {
  try {
    const medication = await Medication.create(req.body);
    
    res.status(201).json({
      success: true,
      data: medication
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error'
    });
  }
};

// Update medication
exports.updateMedication = async (req, res) => {
  try {
    const medication = await Medication.update(req.params.id, req.body);
    
    if (!medication) {
      return res.status(404).json({
        success: false,
        error: 'Medication not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: medication
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error'
    });
  }
};

// Delete medication
exports.deleteMedication = async (req, res) => {
  try {
    const deleted = await Medication.delete(req.params.id);
    
    if (!deleted) {
      return res.status(404).json({
        success: false,
        error: 'Medication not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error'
    });
  }
};

// Update medication stock
exports.updateMedicationStock = async (req, res) => {
  try {
    const { quantity } = req.body;
    
    if (quantity === undefined) {
      return res.status(400).json({
        success: false,
        error: 'Quantity is required'
      });
    }
    
    const medication = await Medication.updateStock(req.params.id, parseInt(quantity));
    
    if (!medication) {
      return res.status(404).json({
        success: false,
        error: 'Medication not found'
      });
    }
    
    res.status(200).json({
      success: true,
      data: medication
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error'
    });
  }
};

// Search medications
exports.searchMedications = async (req, res) => {
  try {
    const { query } = req.params;
    
    if (!query) {
      return res.status(400).json({
        success: false,
        error: 'Search query is required'
      });
    }
    
    const medications = await Medication.search(query);
    
    res.status(200).json({
      success: true,
      count: medications.length,
      data: medications
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: 'Server Error'
    });
  }
};

