// models/Doctor.js
const { v4: uuidv4 } = require('uuid');
const { readDB, writeDB } = require('../config/db');

class Doctor {
  constructor(data) {
    this.id = data.id || uuidv4();
    this.name = data.name;
    this.specialization = data.specialization;
    this.qualification = data.qualification;
    this.experience = data.experience;
    this.contactNumber = data.contactNumber;
    this.email = data.email;
    this.departmentId = data.departmentId;
    this.schedule = data.schedule || [];
    this.createdAt = data.createdAt || new Date().toISOString();
    this.updatedAt = new Date().toISOString();
  }

  static async getAll() {
    return await readDB('doctors.json');
  }

  static async getById(id) {
    const doctors = await this.getAll();
    return doctors.find(doctor => doctor.id === id);
  }

  static async create(doctorData) {
    const doctors = await this.getAll();
    const newDoctor = new Doctor(doctorData);
    doctors.push(newDoctor);
    await writeDB('doctors.json', doctors);
    return newDoctor;
  }

  static async update(id, doctorData) {
    const doctors = await this.getAll();
    const index = doctors.findIndex(doctor => doctor.id === id);
    
    if (index === -1) return null;
    
    const updatedDoctor = new Doctor({
      ...doctors[index],
      ...doctorData,
      id,
      updatedAt: new Date().toISOString()
    });
    
    doctors[index] = updatedDoctor;
    await writeDB('doctors.json', doctors);
    return updatedDoctor;
  }

  static async delete(id) {
    const doctors = await this.getAll();
    const filteredDoctors = doctors.filter(doctor => doctor.id !== id);
    
    if (filteredDoctors.length === doctors.length) return false;
    
    await writeDB('doctors.json', filteredDoctors);
    return true;
  }

  static async getByDepartment(departmentId) {
    const doctors = await this.getAll();
    return doctors.filter(doctor => doctor.departmentId === departmentId);
  }

  static async search(query) {
    const doctors = await this.getAll();
    return doctors.filter(doctor => 
      doctor.name.toLowerCase().includes(query.toLowerCase()) ||
      doctor.specialization.toLowerCase().includes(query.toLowerCase())
    );
  }
}

module.exports = Doctor;

