// routes/departmentRoutes.js
const express = require('express');
const router = express.Router();
const { 
  getAllDepartments, 
  getDepartmentById, 
  createDepartment, 
  updateDepartment, 
  deleteDepartment 
} = require('../controllers/departmentController');
const { protect, authorize } = require('../middleware/auth');

// Public routes
router.get('/', getAllDepartments);
router.get('/:id', getDepartmentById);

// Protected routes
router.use(protect);
router.use(authorize('admin'));

router.post('/', createDepartment);
router.put('/:id', updateDepartment);
router.delete('/:id', deleteDepartment);

module.exports = router;

