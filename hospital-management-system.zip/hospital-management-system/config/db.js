const fs = require('fs').promises;
const path = require('path');

// Ensure data directory exists
const dataDir = path.join(__dirname, '..', 'data');

const initializeDB = async () => {
  try {
    await fs.mkdir(dataDir, { recursive: true });
    
    // Initialize database files if they don't exist
    const dbFiles = ['patients.json', 'doctors.json', 'appointments.json', 
                     'departments.json', 'medications.json', 'users.json'];
    
    for (const file of dbFiles) {
      const filePath = path.join(dataDir, file);
      try {
        await fs.access(filePath);
      } catch (error) {
        // File doesn't exist, create it with empty array
        await fs.writeFile(filePath, JSON.stringify([]));
        console.log(`Initialized ${file}`);
      }
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Error initializing database:', error);
    process.exit(1);
  }
};

const readDB = async (file) => {
  try {
    const data = await fs.readFile(path.join(dataDir, file), 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Error reading from ${file}:`, error);
    throw error;
  }
};

const writeDB = async (file, data) => {
  try {
    await fs.writeFile(
      path.join(dataDir, file),
      JSON.stringify(data, null, 2),
      'utf8'
    );
    return true;
  } catch (error) {
    console.error(`Error writing to ${file}:`, error);
    throw error;
  }
};

module.exports = {
  initializeDB,
  readDB,
  writeDB
};