// routes/medicationRoutes.js
const express = require('express');
const router = express.Router();
const { 
  getAllMedications, 
  getMedicationById, 
  createMedication, 
  updateMedication, 
  deleteMedication, 
  updateMedicationStock, 
  searchMedications 
} = require('../controllers/medicationController');
const { protect, authorize } = require('../middleware/auth');

// Public routes
router.get('/search/:query', searchMedications);

// Protected routes
router.use(protect);

router.route('/')
  .get(getAllMedications)
  .post(authorize('admin'), createMedication);

router.route('/:id')
  .get(getMedicationById)
  .put(authorize('admin'), updateMedication)
  .delete(authorize('admin'), deleteMedication);

router.patch('/:id/stock', authorize('admin', 'staff'), updateMedicationStock);

module.exports = router;

