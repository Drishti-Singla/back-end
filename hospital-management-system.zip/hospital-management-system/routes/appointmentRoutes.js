// routes/appointmentRoutes.js
const express = require('express');
const router = express.Router();
const { 
  getAllAppointments, 
  getAppointmentById, 
  createAppointment, 
  updateAppointment, 
  deleteAppointment, 
  getAppointmentsByPatient, 
  getAppointmentsByDoctor, 
  getAppointmentsByDate, 
  getAppointmentsByStatus 
} = require('../controllers/appointmentController');
const { protect, authorize } = require('../middleware/auth');

// Protected routes
router.use(protect);

router.route('/')
  .get(getAllAppointments)
  .post(createAppointment);

router.route('/:id')
  .get(getAppointmentById)
  .put(updateAppointment)
  .delete(deleteAppointment);

router.get('/patient/:patientId', getAppointmentsByPatient);
router.get('/doctor/:doctorId', getAppointmentsByDoctor);
router.get('/date/:date', getAppointmentsByDate);
router.get('/status/:status', getAppointmentsByStatus);

module.exports = router;

