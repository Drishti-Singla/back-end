// models/User.js
const { v4: uuidv4 } = require('uuid');
const { readDB, writeDB } = require('../config/db');
const bcrypt = require('bcryptjs');

class User {
  constructor(data) {
    this.id = data.id || uuidv4();
    this.username = data.username;
    this.email = data.email;
    this.password = data.password;
    this.role = data.role || 'staff'; // admin, doctor, staff
    this.isActive = data.isActive !== undefined ? data.isActive : true;
    this.lastLogin = data.lastLogin || null;
    this.createdAt = data.createdAt || new Date().toISOString();
    this.updatedAt = new Date().toISOString();
  }

  static async getAll() {
    return await readDB('users.json');
  }

  static async getById(id) {
    const users = await this.getAll();
    return users.find(user => user.id === id);
  }

  static async getByEmail(email) {
    const users = await this.getAll();
    return users.find(user => user.email === email);
  }

  static async getByUsername(username) {
    const users = await this.getAll();
    return users.find(user => user.username === username);
  }

  static async create(userData) {
    const users = await this.getAll();
    
    // Check if email or username already exists
    const existingEmail = users.find(user => user.email === userData.email);
    if (existingEmail) {
      throw new Error('Email already in use');
    }
    
    const existingUsername = users.find(user => user.username === userData.username);
    if (existingUsername) {
      throw new Error('Username already in use');
    }
    
    // Hash password
    const salt = await bcrypt.genSalt(10);
    userData.password = await bcrypt.hash(userData.password, salt);
    
    const newUser = new User(userData);
    users.push(newUser);
    
    // Remove password before returning
    const userToReturn = { ...newUser };
    delete userToReturn.password;
    
    await writeDB('users.json', users);
    return userToReturn;
  }

  static async update(id, userData) {
    const users = await this.getAll();
    const index = users.findIndex(user => user.id === id);
    
    if (index === -1) return null;
    
    // If updating password, hash it
    if (userData.password) {
      const salt = await bcrypt.genSalt(10);
      userData.password = await bcrypt.hash(userData.password, salt);
    }
    
    const updatedUser = new User({
      ...users[index],
      ...userData,
      id,
      updatedAt: new Date().toISOString()
    });
    
    users[index] = updatedUser;
    
    // Remove password before returning
    const userToReturn = { ...updatedUser };
    delete userToReturn.password;
    
    await writeDB('users.json', users);
    return userToReturn;
  }

  static async delete(id) {
    const users = await this.getAll();
    const filteredUsers = users.filter(user => user.id !== id);
    
    if (filteredUsers.length === users.length) return false;
    
    await writeDB('users.json', filteredUsers);
    return true;
  }

  static async authenticate(email, password) {
    const user = await this.getByEmail(email);
    if (!user) return null;
    
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return null;
    
    // Update last login time
    await this.update(user.id, { lastLogin: new Date().toISOString() });
    
    // Return user without password
    const authenticatedUser = { ...user };
    delete authenticatedUser.password;
    
    return authenticatedUser;
  }
}

module.exports = User;