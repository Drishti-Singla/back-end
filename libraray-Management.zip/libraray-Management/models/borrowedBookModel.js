const borrowedBooks = [
    {
        id: "1",
        userId: "1",
        bookId: "1",
        borrowDate: "2023-11-01",
        returnDate: "2023-11-15",
        status: "borrowed"
    },
    {
        id: "2",
        userId: "2",
        bookId: "2",
        borrowDate: "2023-11-02",
        returnDate: "2023-11-16",
        status: "borrowed"
    }
];

module.exports = borrowedBooks;
