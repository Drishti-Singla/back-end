// routes/patientRoutes.js
const express = require('express');
const router = express.Router();
const { 
  getAllPatients, 
  getPatientById, 
  createPatient, 
  updatePatient, 
  deletePatient, 
  searchPatients 
} = require('../controllers/patientController');
const { protect, authorize } = require('../middleware/auth');

// Public routes
router.get('/search/:query', searchPatients);

// Protected routes
router.use(protect);

router.route('/')
  .get(getAllPatients)
  .post(createPatient);

router.route('/:id')
  .get(getPatientById)
  .put(updatePatient)
  .delete(authorize('admin', 'doctor'), deletePatient);

module.exports = router;

