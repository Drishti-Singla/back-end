const resources = [
    {
        id: "1",
        name: "JavaScript Book",
        description: "Complete guide to JavaScript programming"
    },
    {
        id: "2",
        name: "Python Course",
        description: "Interactive Python learning materials"
    },
    {
        id: "3",
        name: "Web Development Kit",
        description: "Tools and resources for web development"
    }
];

module.exports = resources;
