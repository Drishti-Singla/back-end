// models/Appointment.js
const { v4: uuidv4 } = require('uuid');
const { readDB, writeDB } = require('../config/db');

class Appointment {
  constructor(data) {
    this.id = data.id || uuidv4();
    this.patientId = data.patientId;
    this.doctorId = data.doctorId;
    this.date = data.date;
    this.time = data.time;
    this.status = data.status || 'scheduled'; // scheduled, completed, cancelled
    this.notes = data.notes || '';
    this.createdAt = data.createdAt || new Date().toISOString();
    this.updatedAt = new Date().toISOString();
  }

  static async getAll() {
    return await readDB('appointments.json');
  }

  static async getById(id) {
    const appointments = await this.getAll();
    return appointments.find(appointment => appointment.id === id);
  }

  static async create(appointmentData) {
    const appointments = await this.getAll();
    const newAppointment = new Appointment(appointmentData);
    appointments.push(newAppointment);
    await writeDB('appointments.json', appointments);
    return newAppointment;
  }

  static async update(id, appointmentData) {
    const appointments = await this.getAll();
    const index = appointments.findIndex(appointment => appointment.id === id);
    
    if (index === -1) return null;
    
    const updatedAppointment = new Appointment({
      ...appointments[index],
      ...appointmentData,
      id,
      updatedAt: new Date().toISOString()
    });
    
    appointments[index] = updatedAppointment;
    await writeDB('appointments.json', appointments);
    return updatedAppointment;
  }

  static async delete(id) {
    const appointments = await this.getAll();
    const filteredAppointments = appointments.filter(appointment => appointment.id !== id);
    
    if (filteredAppointments.length === appointments.length) return false;
    
    await writeDB('appointments.json', filteredAppointments);
    return true;
  }

  static async getByPatient(patientId) {
    const appointments = await this.getAll();
    return appointments.filter(appointment => appointment.patientId === patientId);
  }

  static async getByDoctor(doctorId) {
    const appointments = await this.getAll();
    return appointments.filter(appointment => appointment.doctorId === doctorId);
  }

  static async getByDate(date) {
    const appointments = await this.getAll();
    return appointments.filter(appointment => appointment.date === date);
  }

  static async getByStatus(status) {
    const appointments = await this.getAll();
    return appointments.filter(appointment => appointment.status === status);
  }
}

module.exports = Appointment;

