// models/Medication.js
const { v4: uuidv4 } = require('uuid');
const { readDB, writeDB } = require('../config/db');

class Medication {
  constructor(data) {
    this.id = data.id || uuidv4();
    this.name = data.name;
    this.description = data.description || '';
    this.dosage = data.dosage;
    this.manufacturer = data.manufacturer || '';
    this.sideEffects = data.sideEffects || [];
    this.stock = data.stock || 0;
    this.expiryDate = data.expiryDate;
    this.createdAt = data.createdAt || new Date().toISOString();
    this.updatedAt = new Date().toISOString();
  }

  static async getAll() {
    return await readDB('medications.json');
  }

  static async getById(id) {
    const medications = await this.getAll();
    return medications.find(medication => medication.id === id);
  }

  static async create(medicationData) {
    const medications = await this.getAll();
    const newMedication = new Medication(medicationData);
    medications.push(newMedication);
    await writeDB('medications.json', medications);
    return newMedication;
  }

  static async update(id, medicationData) {
    const medications = await this.getAll();
    const index = medications.findIndex(medication => medication.id === id);
    
    if (index === -1) return null;
    
    const updatedMedication = new Medication({
      ...medications[index],
      ...medicationData,
      id,
      updatedAt: new Date().toISOString()
    });
    
    medications[index] = updatedMedication;
    await writeDB('medications.json', medications);
    return updatedMedication;
  }

  static async delete(id) {
    const medications = await this.getAll();
    const filteredMedications = medications.filter(medication => medication.id !== id);
    
    if (filteredMedications.length === medications.length) return false;
    
    await writeDB('medications.json', filteredMedications);
    return true;
  }

  static async updateStock(id, quantity) {
    const medication = await this.getById(id);
    if (!medication) return null;
    
    medication.stock += quantity;
    return await this.update(id, { stock: medication.stock });
  }

  static async search(query) {
    const medications = await this.getAll();
    return medications.filter(medication => 
      medication.name.toLowerCase().includes(query.toLowerCase()) ||
      medication.manufacturer.toLowerCase().includes(query.toLowerCase())
    );
  }
}

module.exports = Medication;

